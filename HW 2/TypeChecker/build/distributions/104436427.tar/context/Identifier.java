package context;

import java.util.*;

public interface Identifier {

	public boolean distinct(Object other);

}

