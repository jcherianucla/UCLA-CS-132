package context;

public class MJTypeCheckException extends RuntimeException {
    public MJTypeCheckException() {

    }

    public MJTypeCheckException(String msg) {
        super(msg);
    }
}
