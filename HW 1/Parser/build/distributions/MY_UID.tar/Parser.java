import Components.*;
import Parser.LL1PredictiveParserImpl;
import Tokenizer.Tokenizer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class Parser {

  	/**
  	 * Goes through the grammar to print each non-terminals productions. Used
  	 * primarily for debugging purposes.
  	 **/
    public static void prettyPrintGrammar(Grammar grammar) {
        for(Map.Entry<NonTerminal, Set<Production>> entry: grammar.getGrammarMap().entrySet()) {
            NonTerminal nt = entry.getKey();
            Set<Production> prods = entry.getValue();
            System.out.println("NON-TERMINAL: " + nt.getSymbol());
            for(Production prod : prods) {
                System.out.println("PROD:");
                for(Vocabulary vocab : prod.getSymbols()) {
                    System.out.println(vocab.getSymbol());
                }
            }
        }
    }

  	/**
  	 * Based on a predictive parser, this function prints the first or follow Set
  	 * for each nonTerminal. Used primarily for debugging purposes.
  	 **/
    public static void prettyPrintSets(LL1PredictiveParserImpl parser, boolean first) {
        Map<NonTerminal, Set<Tuple2<Terminal, Integer>>> setMap = first ? parser.getFirstSets() : parser.getFollowSets();
        for(Map.Entry<NonTerminal, Set<Tuple2<Terminal, Integer>>> entry : setMap.entrySet()) {
            NonTerminal nonTerminal = entry.getKey();
            String setType = first ? "First" : "Follow";
            System.out.println(setType + " Set for " + nonTerminal.getSymbol());
            Set<Tuple2<Terminal, Integer>> terminalSet = entry.getValue();
            for(Tuple2<Terminal, Integer> terminalAndProdIdx : terminalSet) {
                System.out.print("(" + terminalAndProdIdx.first.getSymbol() + ", " + terminalAndProdIdx.second.toString() +"), ");
            }
            System.out.print("\n");
        }
    }

    /**
     * Based on a predictive parser, this function prints the resulting pre processed
     * parse table for the supplied grammar. Used primarily for debugging purposes.
     */
    public static void prettyPrintParseTable(HashMap<NonTerminal, HashMap<Terminal, Production>> table) {
        for(NonTerminal nonTerminal : table.keySet()) {
            System.out.println("ROW " + nonTerminal.getSymbol());
            for(Map.Entry<Terminal, Production> entry : table.get(nonTerminal).entrySet()) {
                System.out.print("Terminal: " + entry.getKey().getSymbol() + "\t");
                System.out.print("Production: ");
                if(entry.getValue() == null) {
                    System.out.print("\"\"\n");
                    continue;
                }
                for(Vocabulary vocabulary : entry.getValue().getSymbols()) {
                    System.out.print(vocabulary.getSymbol() + ", ");
                }
                System.out.print("\n");
            }
        }
    }

    public static String readFromFile(String filename) throws FileNotFoundException{
        Scanner scanner = new Scanner(new File(filename));
        String content = scanner.useDelimiter("\\A").next();
        scanner.close();
        return content;
    }

    public static void main(String[] args) {
        String test = "{\n  System.out.println(!false);\n  System.out.println(false);\n}"; //Success
        String test2 = "{ } { }"; //Parse Error
        String test3 = "System.out.println(true);"; //Success
        String test4 = "this is not a program"; // Parse Error
        String test5 = "{\n  System.out.println(!false);\n  System.out.println(true true);\n}"; //Parse Error
        String test6 = "while (true)\n  System.out.println(!false);"; //Success
        String test7 = "{\n  if (true)\n    System.out.println(!false);\n  else\n    System.out.println(false);\n  while (true) {\n    System.out.println(!!false);\n    System.out.println(true);\n  }\n}"; //Success
        String test8 = "System.out.println"; //Error
        String grammarStr = "S:{ L }|System.out.println ( E ) ;|if ( E ) S else S|while ( E ) S\nL:S L |#\nE:true|false|! E";
        Grammar grammar = new Grammar(grammarStr);
        prettyPrintGrammar(grammar);
        System.out.println("------------------------");
        LL1PredictiveParserImpl parser = new LL1PredictiveParserImpl(grammar);
        prettyPrintSets(parser, true);
        System.out.println("------------------------");
        prettyPrintSets(parser, false);
        try {
            String testy = readFromFile(args[1]);
        } catch (FileNotFoundException fe) {
            System.out.println("Could not find the specified file! Please try again.");
            return;
        }
        Tokenizer tokenizer = new Tokenizer(test5);
        try {
            List<Terminal> terminals = tokenizer.generateSequences();
            prettyPrintParseTable(parser.constructParseTable());
            System.out.println(parser.parse(terminals) ? "Program parsed successfully" : "Parse Error");
        } catch(IOException e) {
            System.out.println("Parse Error");
        }
    }
}
